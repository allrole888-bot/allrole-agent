# 🤖 ALLROLE Agent

ALLROLE Agent adalah **smart agent multi fungsi** yang dipublikasikan sebagai NFT.  
Mendukung berbagai jenis task seperti:
- 🔤 Translate
- 📊 Summarize
- 🔢 Calculate
- ⛓️ Integrasi blockchain

---

## 📥 Input Schema
```json
{
  "type": "object",
  "properties": {
    "task": {
      "type": "string",
      "description": "Jenis tugas, contoh: translate, summarize, calculate"
    },
    "data": {
      "type": "string",
      "description": "Data utama yang akan diproses agent"
    }
  },
  "required": ["task", "data"]
}
```

---

## 📤 Output Schema
```json
{
  "type": "object",
  "properties": {
    "result": {
      "type": "string",
      "description": "Hasil pemrosesan"
    },
    "status": {
      "type": "string",
      "enum": ["success", "error"],
      "description": "Status eksekusi"
    }
  },
  "required": ["result", "status"]
}
```

---

## 🚀 Contoh Penggunaan

**Input (`example-input.json`):**
```json
{
  "task": "translate",
  "data": "Halo dunia"
}
```

**Output (`example-output.json`):**
```json
{
  "result": "Hello world",
  "status": "success"
}
```

---

## 📦 Deploy
1. Clone repo ini
   ```bash
   git clone https://github.com/username/allrole-agent.git
   ```
2. Upload `agent.wasm` ke platform blockchain/AI agent marketplace
3. Gunakan `input.json` sesuai kebutuhan

---

## 🏷️ Tags
`automation`, `blockchain`, `AI`, `multi-function`
